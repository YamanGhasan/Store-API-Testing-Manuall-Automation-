﻿using automationTest.API;
using automationTest.Models;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Security.Policy;
using System.Web.Http;

public static class CartController
{
    [HttpGet]
    public static int GetStatusCode()
    {
        HttpResponseMessage response = Request.testRequest();
        return (int)response.StatusCode;
    }
    [HttpGet]
    public static Cart GetCartData()
    {
        HttpResponseMessage response = Request.testRequest();
        if (response.IsSuccessStatusCode)
        {
            string content = response.Content.ReadAsStringAsync().Result;
            return JsonConvert.DeserializeObject<Cart>(content);
        }
        else
        {
            return null; 
        }
    }
}
