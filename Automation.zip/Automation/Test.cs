﻿using NUnit.Framework.Legacy;
using NUnit.Framework;
using System;
 using System.Linq;
using automationTest.Models;
using automationTest.API;

namespace automationTest
{
    public class Test
    {
      

       

        [Test]
        public void VerifyStatusCode() 
        {
            int statusCode = CartController.GetStatusCode();
            ClassicAssert.AreEqual(200, statusCode, "Status code is not 200");

        }
        [Test]
        public void VerifyCartID()
        {
            Cart cart = CartController.GetCartData();
            ClassicAssert.IsNotNull(cart, "Cart with ID 5 does not exist.");
            ClassicAssert.AreEqual(5, cart.Id, "Cart ID is not 5");
        }
        [Test]
        public void VerifyCartContainsProducts()
        {
            Cart cart = CartController.GetCartData();
            ClassicAssert.IsNotNull(cart, "Cart with ID 5 does not exist.");
            ClassicAssert.IsNotNull(cart.Products, "Cart does not contain a products list.");
            ClassicAssert.IsTrue(cart.Products.Count > 0, "Cart does not contain any products.");
        }

    }
}