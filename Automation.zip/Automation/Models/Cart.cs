﻿using System;
using System.Collections.Generic;

namespace automationTest.Models
{
    public class Cart
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public DateTime Date { get; set; }
        public List<Product> Products { get; set; }
        public int Version { get; set; }
    }

    public class Product
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
