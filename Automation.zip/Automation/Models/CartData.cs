﻿ 

namespace automationTest.Models
{
    public class CartsData
    {
        public static Cart CartData { get; set; }

    }
}