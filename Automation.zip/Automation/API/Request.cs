﻿using automationTest.Models;
using Newtonsoft.Json;
using System.Net.Http;
 

namespace automationTest.API
{
    public static class Request
    {
        private static HttpClient restClient = new HttpClient();
        private static string URI = "https://fakestoreapi.com/carts/5";

        public static HttpResponseMessage testRequest()
        {
            HttpResponseMessage response = restClient.GetAsync(URI).Result;
            return response;

        }
    }
}